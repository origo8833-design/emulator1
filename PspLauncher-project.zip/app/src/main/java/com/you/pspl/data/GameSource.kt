package com.you.pspl.data

import android.content.Context
import androidx.documentfile.provider.DocumentFile

/** Source de fichiers d'un jeu : une ISO ou un dossier de jeu. */
interface GameSource : AutoCloseable {
    fun read(path: String): ByteArray?
}

/** Jeu PS3 au format dossier (contient PS3_GAME/...), lu via le Storage Access Framework. */
class FolderSource(private val ctx: Context, private val root: DocumentFile) : GameSource {
    override fun read(path: String): ByteArray? {
        var cur: DocumentFile = root
        for (p in path.split('/')) {
            cur = cur.listFiles().firstOrNull { it.name.equals(p, ignoreCase = true) } ?: return null
        }
        if (!cur.isFile) return null
        return ctx.contentResolver.openInputStream(cur.uri)?.use { it.readBytes() }
    }

    override fun close() {}
}
