package com.you.pspl.data

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.security.MessageDigest
import java.util.Properties

object GameScanner {
    fun scan(ctx: Context, platform: Platform, tree: Uri): List<Game> {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return emptyList()
        val out = mutableListOf<Game>()
        walk(ctx, platform, root, out, 0)
        return out.sortedBy { it.title.lowercase() }
    }

    private fun walk(ctx: Context, p: Platform, dir: DocumentFile, out: MutableList<Game>, depth: Int) {
        val children = dir.listFiles()
        // Jeu PS3 en dossier : contient un sous-dossier PS3_GAME
        if (p == Platform.PS3 && children.any { it.isDirectory && it.name.equals(p.gameDir, true) }) {
            index(ctx, p, dir, folder = true)?.let { out.add(it) }
            return
        }
        for (c in children) {
            if (c.isDirectory) { if (depth < 6) walk(ctx, p, c, out, depth + 1) }
            else if (c.name?.endsWith(".iso", true) == true) index(ctx, p, c, folder = false)?.let { out.add(it) }
        }
    }

    private fun sha1(s: String) = MessageDigest.getInstance("SHA-1")
        .digest(s.toByteArray()).joinToString("") { "%02x".format(it) }.take(16)

    private fun index(ctx: Context, p: Platform, f: DocumentFile, folder: Boolean): Game? {
        val rawName = f.name ?: return null
        val fallback = if (folder) rawName else rawName.substringBeforeLast('.')
        val key = sha1("${f.uri}|${f.lastModified()}|${f.length()}")
        val dir = File(ctx.filesDir, "cache/$key").apply { mkdirs() }
        val meta = File(dir, "meta.properties")
        val props = Properties()
        if (meta.exists()) runCatching { meta.reader(Charsets.UTF_8).use { props.load(it) } }

        // Pas encore en cache : on ouvre l'ISO / le dossier une seule fois
        if (props.getProperty("title") == null) {
            val ok = runCatching {
                val src: GameSource = if (folder) FolderSource(ctx, f) else PspIso(ctx, f.uri)
                src.use { s ->
                    val sfo = s.read("${p.gameDir}/PARAM.SFO")?.let { parseSfo(it) } ?: emptyMap()
                    props.setProperty("title", sfo["TITLE"]?.ifBlank { null } ?: fallback)
                    props.setProperty("id", sfo[p.idKey] ?: "")
                    fun dump(name: String, dst: String) {
                        val data = s.read("${p.gameDir}/$name") ?: return
                        File(dir, dst).writeBytes(data)
                    }
                    dump("ICON0.PNG", "icon.png")
                    dump("PIC1.PNG", "bg.png")                       // PIC1 = fond plein écran
                    if (!File(dir, "bg.png").exists()) dump("PIC0.PNG", "bg.png")
                    dump("SND0.AT3", "bgm.at3")                      // musique d'ambiance
                }
            }.onFailure { Log.w("GameScanner", "Lecture impossible : $rawName", it) }.isSuccess
            if (ok) meta.writer(Charsets.UTF_8).use { props.store(it, null) }
            else props.setProperty("title", fallback)                // pas de cache : on réessaiera
        }

        fun cached(name: String) = File(dir, name).takeIf { it.exists() && it.length() > 0 }
        return Game(
            platform = p,
            title = props.getProperty("title") ?: fallback,
            id = props.getProperty("id") ?: "",
            key = key,
            uri = f.uri,
            icon = cached("icon.png"),
            background = cached("bg.png"),
            music = cached("bgm.at3"),
            dir = dir,
        )
    }
}
