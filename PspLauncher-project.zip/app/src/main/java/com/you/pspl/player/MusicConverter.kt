package com.you.pspl.player

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Android ne lit pas l'ATRAC3+ : on convertit SND0.AT3 en .m4a une seule fois (cache).
 * Garde-fou : si l'appli meurt pendant une conversion (crash natif ffmpeg), la musique
 * est coupée automatiquement au lancement suivant au lieu de replanter en boucle.
 */
object MusicConverter {
    private val lock = Mutex()   // une conversion à la fois
    private lateinit var prefs: SharedPreferences
    @Volatile private var running = false
    var autoDisabled = false
        private set

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("p", Context.MODE_PRIVATE)
        if (prefs.getBoolean("ffmpeg_busy", false)) {
            prefs.edit().putBoolean("ffmpeg_busy", false).putBoolean("music", false).apply()
            autoDisabled = true
        }
    }

    var enabled: Boolean
        get() = prefs.getBoolean("music", true)
        set(v) { prefs.edit().putBoolean("music", v).apply() }

    /** À appeler quand l'appli passe en arrière-plan. */
    fun cancelAll() { if (running) runCatching { FFmpegKit.cancel() } }

    suspend fun ensure(raw: File?): File? {
        if (!enabled || raw == null || !raw.exists()) return null
        val out = File(raw.parentFile, "bgm.m4a")
        if (out.exists() && out.length() > 0) return out
        return lock.withLock {
            if (out.exists() && out.length() > 0) return@withLock out
            val tmp = File(raw.parentFile, "bgm.tmp.m4a").apply { delete() }
            val ok = convert(raw, tmp)
            if (ok && tmp.length() > 0 && tmp.renameTo(out)) out else { tmp.delete(); null }
        }
    }

    private suspend fun convert(src: File, dst: File): Boolean = suspendCancellableCoroutine { cont ->
        prefs.edit().putBoolean("ffmpeg_busy", true).commit()   // écrit AVANT de toucher au natif
        running = true
        try {
            val session = FFmpegKit.executeAsync(
                "-y -i \"${src.absolutePath}\" -vn -c:a aac -b:a 128k \"${dst.absolutePath}\""
            ) { s ->
                running = false
                prefs.edit().putBoolean("ffmpeg_busy", false).apply()
                val ok = ReturnCode.isSuccess(s.returnCode)
                if (!ok && !ReturnCode.isCancel(s.returnCode)) {
                    Log.w("MusicConverter", "ffmpeg a échoué sur ${src.name} : ${s.logsAsString}")
                }
                if (cont.isActive) cont.resume(ok)
            }
            cont.invokeOnCancellation { FFmpegKit.cancel(session.sessionId) }
        } catch (t: Throwable) {   // ex. UnsatisfiedLinkError : lib native incompatible
            Log.e("MusicConverter", "ffmpeg indisponible", t)
            running = false
            prefs.edit().putBoolean("ffmpeg_busy", false).putBoolean("music", false).apply()
            if (cont.isActive) cont.resume(false)
        }
    }
}
