package com.you.pspl.ui

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.you.pspl.data.Game
import com.you.pspl.data.Library
import com.you.pspl.data.Platform
import com.you.pspl.launch.launchGame
import com.you.pspl.player.Bgm
import com.you.pspl.player.MusicConverter
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

enum class Nav { LEFT, RIGHT, UP, DOWN, SELECT, BACK, OPTIONS, TAB_PREV, TAB_NEXT }

/** TABS = barre des bibliothèques (en haut), ROW = rangée de jeux, comme sur l'accueil PS5. */
private enum class Zone { TABS, ROW }

private class MenuItem(val label: String, val action: () -> Unit)

private const val CUSTOM = "custom_bg"

private fun clock(): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

private fun customFiles(g: Game): List<File> =
    g.dir.listFiles { f -> f.name.startsWith(CUSTOM) }?.toList() ?: emptyList()

/** Horloge isolée : ne recompose pas tout l'écran toutes les 15 s. */
@Composable
private fun Clock() {
    var time by remember { mutableStateOf(clock()) }
    LaunchedEffect(Unit) { while (true) { time = clock(); delay(15_000) } }
    Text(time, color = Color.White, fontSize = 18.sp)
}

@Composable
fun HomeScreen(
    libs: List<Library>,
    nav: Flow<Nav>,
    onPickFolder: (Platform) -> Unit,
    onRescan: (Platform) -> Unit,
) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", Context.MODE_PRIVATE) }
    var tab by remember { mutableIntStateOf(prefs.getInt("lib", 0).coerceIn(0, libs.lastIndex)) }
    val idx = remember { mutableStateListOf(*Array(libs.size) { prefs.getInt("idx_$it", 0) }) }
    var zone by remember { mutableStateOf(Zone.ROW) }
    var showMenu by remember { mutableStateOf(false) }
    var menuIndex by remember { mutableIntStateOf(0) }
    var musicOn by remember { mutableStateOf(MusicConverter.enabled) }
    val listState = rememberLazyListState()

    val lib = libs[tab]
    val games = lib.games
    val index = idx[tab].coerceIn(0, (games.size - 1).coerceAtLeast(0))
    val selected = games.getOrNull(index)

    // Fonds personnalisés (un par jeu), relus depuis le disque quand la liste change
    val customBg = remember { mutableStateMapOf<String, File>() }
    LaunchedEffect(libs.sumOf { it.games.size }) {
        withContext(Dispatchers.IO) {
            libs.flatMap { it.games }.forEach { g ->
                customFiles(g).firstOrNull()?.let { customBg[g.key] = it }
            }
        }
    }
    fun bgOf(g: Game?): File? = g?.let { customBg[it.key] ?: it.background }

    fun save() {
        val e = prefs.edit().putInt("lib", tab)
        idx.forEachIndexed { i, v -> e.putInt("idx_$i", v) }
        e.apply()
    }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        val g = selected
        if (uri != null && g != null) {
            runCatching {
                customFiles(g).forEach { it.delete() }
                val out = File(g.dir, "${CUSTOM}_${System.currentTimeMillis()}.img")
                ctx.contentResolver.openInputStream(uri)?.use { i ->
                    out.outputStream().use { o -> i.copyTo(o) }
                }
                customBg[g.key] = out
            }
        }
        showMenu = false
    }

    fun switchTab(d: Int) {
        val n = (tab + d).coerceIn(0, libs.lastIndex)
        if (n != tab) { tab = n; showMenu = false }
    }
    fun move(d: Int) {
        if (games.isNotEmpty()) { idx[tab] = (index + d).coerceIn(0, games.lastIndex) }
    }
    fun play() {
        val g = selected ?: return
        if (!launchGame(ctx, g)) {
            Toast.makeText(ctx, "Impossible de lancer ${g.platform.emulator}", Toast.LENGTH_LONG).show()
        }
    }

    val menuItems = buildList {
        if (selected != null) {
            add(MenuItem("🖼  Changer l'image de fond") { imagePicker.launch(arrayOf("image/*")) })
            add(MenuItem("↩  Revenir au fond d'origine") {
                customFiles(selected).forEach { it.delete() }
                customBg.remove(selected.key)
                showMenu = false
            })
        }
        add(MenuItem("📁  Changer le dossier ${lib.platform.label}") { showMenu = false; onPickFolder(lib.platform) })
        add(MenuItem(if (musicOn) "🔊  Musique d'ambiance : activée" else "🔇  Musique d'ambiance : désactivée") {
            musicOn = !musicOn; MusicConverter.enabled = musicOn; showMenu = false
        })
        add(MenuItem("🔄  Rescanner la bibliothèque") { showMenu = false; onRescan(lib.platform) })
        add(MenuItem("Fermer") { showMenu = false })
    }

    // Événements manette (voir MainActivity)
    val onNav by rememberUpdatedState<(Nav) -> Unit>({ n ->
        if (showMenu) {
            when (n) {
                Nav.UP -> menuIndex = (menuIndex - 1).coerceAtLeast(0)
                Nav.DOWN -> menuIndex = (menuIndex + 1).coerceAtMost(menuItems.lastIndex)
                Nav.SELECT -> menuItems.getOrNull(menuIndex)?.action?.invoke()
                Nav.BACK, Nav.OPTIONS -> showMenu = false
                else -> {}
            }
        } else {
            when (n) {
                Nav.TAB_PREV -> switchTab(-1)
                Nav.TAB_NEXT -> switchTab(1)
                Nav.LEFT -> if (zone == Zone.TABS) switchTab(-1) else move(-1)
                Nav.RIGHT -> if (zone == Zone.TABS) switchTab(1) else move(1)
                Nav.UP -> zone = Zone.TABS
                Nav.DOWN -> zone = Zone.ROW
                Nav.SELECT -> when {
                    zone == Zone.TABS -> zone = Zone.ROW
                    lib.loading -> {}
                    selected == null -> onPickFolder(lib.platform)
                    else -> play()
                }
                Nav.BACK -> zone = Zone.ROW
                Nav.OPTIONS -> { menuIndex = 0; showMenu = true }
            }
        }
    })
    LaunchedEffect(Unit) { nav.collect { onNav(it) } }

    LaunchedEffect(tab, index) { delay(400); save() }   // sauvegarde différée (pas à chaque pas)
    LaunchedEffect(tab, index) {
        if (games.isNotEmpty()) listState.animateScrollToItem((index - 1).coerceAtLeast(0))
    }

    // Musique d'ambiance du jeu sélectionné : conversion une seule fois (cache),
    // annulée si on change de jeu, puis préchargement des voisins.
    LaunchedEffect(selected?.key, musicOn) {
        delay(500)
        Bgm.play(if (musicOn) MusicConverter.ensure(selected?.music) else null)
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Crossfade(targetState = bgOf(selected), label = "bg") { bg ->
            AsyncImage(
                model = bg, contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color(0xCC000000), Color(0x22000000), Color(0xF0000000))
                )
            )
        )

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp)
        ) {
            // Barre du haut : les deux bibliothèques + l'heure
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                libs.forEachIndexed { i, l ->
                    val sel = i == tab
                    val focus = sel && zone == Zone.TABS
                    Text(
                        l.platform.label,
                        color = when { focus -> Color.Black; sel -> Color.White; else -> Color(0x99FFFFFF) },
                        fontSize = 16.sp,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (focus) Color.White else Color.Transparent)
                            .clickable { tab = i; zone = Zone.ROW; showMenu = false }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Spacer(Modifier.weight(1f))
                Clock()
            }
            Spacer(Modifier.height(14.dp))

            if (selected == null) {
                // Bibliothèque vide / dossier non choisi / scan en cours
                Column(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    if (lib.loading) {
                        CircularProgressIndicator(color = Color.White)
                    } else {
                        Text(
                            if (!lib.hasFolder) "Aucun dossier choisi pour ${lib.platform.label}"
                            else "Aucun jeu trouvé dans ce dossier",
                            color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick = { onPickFolder(lib.platform) },
                            border = if (zone == Zone.ROW) BorderStroke(2.dp, Color.White) else null,
                        ) { Text("✕  Choisir le dossier des jeux ${lib.platform.emulator}") }
                    }
                }
            } else {
                // Rangée unique d'icônes
                LazyRow(
                    state = listState,
                    modifier = Modifier.height(112.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    itemsIndexed(games) { i, g ->
                        val isSel = i == index
                        val h by animateDpAsState(if (isSel) 80.dp else 52.dp, label = "h")
                        val ring = when {
                            !isSel -> Color.Transparent
                            zone == Zone.ROW -> Color.White
                            else -> Color(0x88FFFFFF)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            AsyncImage(
                                model = g.icon, contentDescription = g.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(h).aspectRatio(144f / 80f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(if (isSel) 2.dp else 0.dp, ring, RoundedCornerShape(12.dp))
                                    .clickable { idx[tab] = i; zone = Zone.ROW },
                            )
                            if (isSel) {
                                Text(
                                    g.title, color = Color.White, fontSize = 11.sp, maxLines = 1,
                                    modifier = Modifier.widthIn(max = 150.dp).padding(top = 4.dp),
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.weight(1f))

                Text(
                    selected.title, color = Color.White, fontSize = 30.sp,
                    fontWeight = FontWeight.Bold, maxLines = 2,
                )
                if (selected.id.isNotBlank()) {
                    Text(selected.id, color = Color(0xCCFFFFFF), fontSize = 14.sp)
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { play() },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White, contentColor = Color.Black),
                    ) { Text("▶  Jouer", fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(12.dp))
                    Box(
                        Modifier.size(44.dp).clip(CircleShape)
                            .background(Color(0x66FFFFFF))
                            .clickable { menuIndex = 0; showMenu = true },
                        contentAlignment = Alignment.Center,
                    ) { Text("⚙", color = Color.White, fontSize = 22.sp) }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                if (showMenu) "✕ Valider     ○ Fermer"
                else "✕ Jouer     ○ Retour     OPTIONS Options     L1 / R1 Bibliothèque     ▲ Barre du haut",
                color = Color(0x99FFFFFF), fontSize = 12.sp,
            )
        }

        // Panneau d'options (menu OPTIONS de la manette)
        if (showMenu) {
            Box(
                Modifier.fillMaxSize().background(Color(0xAA000000))
                    .clickable { showMenu = false },
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    Modifier.widthIn(max = 420.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xF01C1C1E))
                        .clickable(onClick = {})
                        .padding(16.dp),
                ) {
                    Text(
                        "Options : ${selected?.title ?: lib.platform.label}", color = Color.White,
                        fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                        modifier = Modifier.padding(bottom = 10.dp),
                    )
                    menuItems.forEachIndexed { i, item ->
                        val on = menuIndex == i
                        Text(
                            item.label,
                            color = if (on) Color.Black else Color.White,
                            fontSize = 16.sp,
                            modifier = Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (on) Color.White else Color.Transparent)
                                .clickable { menuIndex = i; item.action() }
                                .padding(12.dp),
                        )
                    }
                }
            }
        }
    }
}
