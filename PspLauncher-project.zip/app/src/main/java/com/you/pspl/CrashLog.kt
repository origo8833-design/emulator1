package com.you.pspl

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File

/** Écrit le crash Java sur disque ; au lancement suivant l'appli l'affiche pour qu'on puisse le copier. */
object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "crash.txt")

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                file(app).writeText(
                    "Android ${Build.VERSION.SDK_INT} · ${Build.MANUFACTURER} ${Build.MODEL}\n" +
                        "Thread : ${t.name}\n\n" + Log.getStackTraceString(e)
                )
            }
            old?.uncaughtException(t, e)
        }
    }

    fun pending(ctx: Context): String? =
        runCatching { file(ctx).takeIf { it.exists() }?.readText()?.take(8000) }.getOrNull()

    fun clear(ctx: Context) { runCatching { file(ctx).delete() } }

    /** Crash natif (ffmpeg…), ANR ou manque de mémoire : invisibles pour le handler Java (Android 11+). */
    fun systemExit(ctx: Context): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        val am = ctx.getSystemService(ActivityManager::class.java) ?: return null
        val info = runCatching { am.getHistoricalProcessExitReasons(ctx.packageName, 0, 1).firstOrNull() }
            .getOrNull() ?: return null
        val prefs = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)
        if (info.timestamp <= prefs.getLong("exit_seen", 0L)) return null
        prefs.edit().putLong("exit_seen", info.timestamp).apply()
        val what = when (info.reason) {
            ApplicationExitInfo.REASON_CRASH_NATIVE -> "Crash natif (bibliothèque C/C++, probablement ffmpeg)"
            ApplicationExitInfo.REASON_ANR -> "L'appli ne répondait plus (ANR)"
            ApplicationExitInfo.REASON_LOW_MEMORY -> "Fermée par Android : manque de mémoire"
            else -> return null
        }
        return "Android ${Build.VERSION.SDK_INT} · ${Build.MANUFACTURER} ${Build.MODEL}\n$what\n${info.description ?: ""}"
    }
}
