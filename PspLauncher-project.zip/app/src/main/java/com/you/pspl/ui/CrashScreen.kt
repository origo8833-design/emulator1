package com.you.pspl.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CrashScreen(report: String, onClose: () -> Unit) {
    val clip = LocalClipboardManager.current
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
        Text("L'appli a planté la dernière fois", color = Color.White,
            fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Copie ce rapport et envoie-le à Claude pour corriger.",
            color = Color(0xCCFFFFFF), fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        SelectionContainer(Modifier.weight(1f)) {
            Text(report, color = Color(0xFFFFB4AB), fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                modifier = Modifier.verticalScroll(rememberScrollState()))
        }
        Spacer(Modifier.height(8.dp))
        Row {
            Button(onClick = { clip.setText(AnnotatedString(report)) }) { Text("Copier") }
            Spacer(Modifier.width(12.dp))
            Button(onClick = onClose) { Text("Continuer") }
        }
    }
}
